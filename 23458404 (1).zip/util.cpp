#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <string.h>
#include <sstream>
#include "avl.h"
#include <time.h>
using namespace std;
//this  file contains all the functions
void EchoData(string tablename, int recordSize, int numColumns);

vector<string> GetRecord(string tablename, streamoff pos, int numColumns);

vector<streamoff> LinearSearch(string tablename, int recordSize, int numColumns, string matchValue, int matchColumn);

avltree<string, streamoff>avl;// echo data function reads record by record
void EchoData(string tablename, int recordSize, int numColumns)
{
	string   filename = tablename + ".data";
	ifstream data(filename, ios::in | ios::binary);

	if (!data.good())
	{
		cout << "**Error: couldn't open data file '" << filename << "'." << endl;
		return;
	}

	//
	// Okay, read file record by record, and output each record of values:
	//
	data.seekg(0, data.end);  // move to the end to get length of file:
	streamoff length = data.tellg();

	streamoff pos = 0;  // first record at offset 0:
	string    value;

	while (pos < length)
	{
		data.seekg(pos, data.beg);  // move to start of record:

		for (int i = 0; i < numColumns; ++i)  // read values, one per column:
		{
			
				//data >> value;
				
					data >> value>>value;
					cout << value << " now insert " << endl;
			
				//cout << value << " ";
			
		}

		cout << endl;
		pos += recordSize;  // move offset to start of next record:
	}
}

//returns the data if the search is not linear (meaning if we have a tree)
vector<string> GetRecord(string tablename, streamoff pos, int numColumns)
{
	vector<string>  values;
	string filename = tablename + ".data";

	ifstream data(filename, ios::in | ios::binary);

	data.seekg(pos);
	string take;
	for (int i = 0; i < numColumns; i++)
	{
		data >> take;
		values.push_back(take);
		//cout << values[i] << endl;
	}
	


	//
	// open the file, make sure it opened, seekg to the given position,
	// loop and input values using >>, store into vector, return vector
	//

	return values;
}

//returns the position of data by searching the whole file (works when we dont have any treees)

vector<streamoff> LinearSearch(string tablename, int recordSize, int numColumns, string matchValue, int matchColumn)
{
	vector<streamoff>  matches;

	


	string   filename = tablename + ".data";
	ifstream data(filename, ios::in | ios::binary);

	if (!data.good())
	{
		cout << "**Error: couldn't open data file '" << filename << "'." << endl;
		return matches;
	}

	//
	// Okay, read file record by record, and output each record of values:
	//
	data.seekg(0, data.end);  // move to the end to get length of file:
	streamoff length = data.tellg();

	streamoff pos = 0;  // first record at offset 0:
	string    value;

	while (pos < length)
	{
		data.seekg(pos, data.beg);  // move to start of record:

		for (int i = 0; i < numColumns; i++)  // read values, one per column:
		{

			data >> value;
			if (matchColumn-1 == i)
			{

				if (value == matchValue)
				{
					
					matches.push_back(pos);
					
				
					
				}
			}


		}

		pos += recordSize;  // move offset to start of next record:
	
	}


	return matches;
}


vector<string> tokenize(string line)
{
	vector<string> tokens;
	stringstream  stream(line);
	string token;

	while (getline(stream, token, ' '))
	{
		tokens.push_back(token);
	}

	return tokens;
}

//This function reads .meta file and store column name and indexes in 2 different vectors
vector<int> readdata(string tablename, vector<int>&V, vector<string>&V1)
{
		
string uin, netid;
string offset;
int numcolumns = 1;
int matchcolumn = 1;

//vector<string>V1; //to get the names on each column
string filename = tablename + ".meta";

ifstream data(filename, ios::in);

if (!data.good())
{
	cout << "**Error: couldn't open data file '" << filename << "'." << endl;
	//break;
	return V;
}
string val;
int values;
//


data >> values;
V.push_back(values);
data >> values;
V.push_back(values);
while (!data.eof())
{
	//int i = 0;
	data >> val;
	V1.push_back(val);
	for (unsigned i = 0; i <= numcolumns; i++)
	{


		if (i == matchcolumn)
		{
			
			data >> val;
			if (val == "1")
			{
				V.push_back(1);
			}
			else

			{
				V.push_back(0);
			} 
		}

	}

}
V.pop_back(); // extra value at because we are reading input at top so at the end it will loop through one extra time to check if file is empty or not	
V1.pop_back();


return V;
}

// this is the main function where we check for the indexes to build trees and perform all the query operations
	void avlbuild(string tablename, vector<int> V, vector<string> V1)
	{

		//here read all the file through vector using for loop iterate the loop until index is found both for meta and data file
		vector<string>readdata;
		string   filename = tablename + ".data";
		ifstream data(filename, ios::in | ios::binary);

		if (!data.good())
		{
			cout << "**Error: couldn't open data file '" << filename << "'." << endl;
			return;
		}

		//
		// Okay, read file record by record, and output each record of values:
		//
		data.seekg(0, data.end);  // move to the end to get length of file:
		streamoff length = data.tellg();

		streamoff pos = 0;  // first record at offset 0:
		string    value;
		string prev;
		int recordsize = V[0];
		vector<avltree< string, streamoff>>mytree(V.size());
		while (pos < length)
		{
			data.seekg(pos, data.beg);  // move to start of record:


			for (unsigned i = 0; i <= V[1]+1; i++)
			{

				if (V[i] == 1)
				{
					prev = value;
					data >> value;
				//	if (prev == value)
				//	{
				//		break;
				//	}
					//so at this point we have to create multiple trees with unique identity.. okay ? I have an idea we can create a tree on specific index
					//lets choose the range of tree as 1 because each time it finds index it will run the loop
					for (int j = 0; j < 1; j++)
					{

						mytree[i].insert(value, pos);
					}
					//	cout << value << " : " << pos << "  " << " build index " << endl;

				}
				else if (V[i] == 0)
				{
					data >> value;

					//cout << "linear search" << endl;
				}
				else
				{
					//data >> value;
					//	cout << "linear search" << endl;
				}
				//	}
				//	data >> value >> value;
					//cout << value << " now insert " << endl;

					//cout << value << " ";

			}

			//	cout << endl;
			pos += recordsize;  // move offset to start of next record:
		}

	
		//////////////////////////////////////
		for (int i = 0; i <= V[1]+1; i++)
		{

			if (V[i] == 1)
			{
			//printing the correct column height and size for the indexes which are 1
				cout << "Index column: " << V1.at(i-2) << " " << endl;
				cout << "  Tree size: " << mytree[i].size() << endl;
				cout << "  Tree height: " << mytree[i].height() << endl;
			}
			else if (V[i] == 0)
			{
				data >> value;

				//cout << "linear search" << endl;
			}
			else
			{
				//	cout << "linear search" << endl;
				continue;
			}
		
		
		}
        
        //this whole part is dealing with the query errors and making sure all the queries are correct
		bool t0 = true;
		bool t1 = true;
		bool t2 = true;
		bool t3 = true;
		bool t4 = true;
		bool t5 = true;
		bool t6 = true;

		int columnindex1;

		string query;

		cout << endl;

		cout << "Enter query> ";

		getline(cin, query);
		//will work on it tomorrow
		int i;
		while (query != "exit")
		{
			vector<string> tokens = tokenize(query);

			if (tokens[0] != "select" && tokens[0] != "exit")
			{
				cout << "Unknown query, ignored..." << endl;
				t0 = false;
				//break;
			}
			else
			{
				t0 = true;
			}
			if (tokens[0] == "select" && tokens[1] != "*")
			{
				for (i = 0; i < V1.size(); i++)
				{
					if (tokens[1] == V1[i] && i + 1 != V1.size())
					{

						t1 = true;
						//columnindex = i;
						break;

						//break;
					}
					else if (tokens[1] != V1[i] && i + 1 == V1.size())
					{
						cout << " Invalid select column, ignored..." << endl;
						t1 = false;
						break;
					}
					//	cout << " wrong column name" << endl;				
					else
					{
						continue;
					}

				}

			}
			if (t0 == true)
			{
				if (tokens[2] != "from")
				{
					cout << "Invalid select query, ignored..." << endl;
					t2 = false;
				//	break;
				}
				else
				{
					t2 = true;
				}
			}
			if (t0 == true)
			{
				if (tokens[3] != tablename && t0 == true && t2 == true)
				{
					cout << "Invalid table name, ignored..." << endl;
					t3 = false;
					//break;


				}
				else
				{
					t3 = true;
				}
			}
			if (t0 == true)
			{
				if (tokens[4] != "where"  && t0 == true && t3 == true && t2 == true)
				{
					cout << "Invalid select query, ignored..." << endl;
					t4 = false;

				}
				else
				{
					t4 = true;
				}
			}
			///focus on this part not working properly // make sure you are able to read the last element of file
			for (i = 0; i < V1.size(); i++)
			{
				if (t0 == true)
				{
					if (tokens[5] == V1[i] && i != V1.size() && t0 == true && t3 == true && t2 == true && t4 == true)
					{
						t5 = true;
						columnindex1 = i + 2;
						break;


						//break;
					}
					else if (tokens[5] != V1[i] && i == V1.size()-1 && t0 == true && t3 == true && t2 == true && t4 == true)
					{
						cout << " Invalid where column, ignored..." << endl;
						t5 = false;
						//break;

						///sdazd
					}
					//	cout << " wrong column name" << endl;				
					else
					{
						continue;
					}

				}
			}
			if (t0 == true)
			{
				if (tokens[6] != "=" && t0 == true)
				{
					cout << "Invalid select query, ignored... " << endl;
					t6 = false;
					//break;
				}
				else if (tokens[6] == "=" && t0 == true)
				{
					t6 = true;
				}
			}

            //this part will perform searches depending if we have a index for it or no
            ////if we dont have the index then it will do linear search
			if (t0 == true && t1 == true && t2 == true && t3 == true && t4 == true && t5 == true && t6 == true) // making sure that all the above input is fine
			{
				if (tokens[7] == "0")
				{
					cout << "Not found..." << endl;
				}
				else
				{
						//checking the index here ?? if we have a index or not
					if (V[columnindex1] == 1 && tokens[1]=="*" && V[columnindex1] != 0) // select * from ----- where ---- this is done 1 query is done
			{
					
					streamoff *search=mytree[columnindex1].search(tokens[7]);
				
					if (search == nullptr)   //checking if the search is null or no (meaning the token[7] is valid or not )
					{
						cout << "Not found..." << endl;
						//break;
					}
					else if(search != nullptr)
					{
						vector<string>forall;
						forall = GetRecord(tablename, *search, V[1]);   //doing some search using trees

						for (unsigned i = 0; i < V1.size(); i++)
						{
							cout << V1[i] << ": " << forall[i] << endl;  //printing the data using getrecord (meaning we have a tree for it )
						}
					
					}
			}
					else if (V[columnindex1] == 1 && tokens[1] != "*" && V[columnindex1] !=0) //doing some searches using trees
					{
					
						streamoff *search1 = mytree[columnindex1].search(tokens[7]);
						if (search1 == nullptr)
						{
							cout << "Not found..." << endl;
							//break;
						}
                        else if(search1 != nullptr)
                        {
						readdata = GetRecord(tablename, *search1, V[1]);

						for (unsigned i = 0; i < V1.size(); i++)
						{
							if (tokens[1] == V1[i])
							{
								cout << tokens[1] << ": " << readdata[i] << endl;
							}
						}
                        }
					}
                    //Linear search part is here
					else if (V[columnindex1] == 0 && tokens[1]=="*" && V[columnindex1] !=1) //doing some linear search using trees
					{
						vector<streamoff> linear;   ///
						linear =LinearSearch(tablename, V[0], V[1], tokens[7], columnindex1 - 1);
						if (linear.size() == 0)
						{
							cout << "Not found..." << endl;
							//break;
						}
                        else if(linear.size() != 0)
                        {
						for (unsigned i = 0; i < linear.size(); i++)
						{
							readdata = GetRecord(tablename, linear[i], V[1]);


							for (unsigned i = 0; i < V1.size(); i++)
							{
								cout << V1[i] << ": " << readdata[i] << endl;

							}

						}
                       }
					}

					else 
					{
						if (V[columnindex1] == 0 && tokens[1] != "*")
						{
							vector<streamoff> linear;
							linear = LinearSearch(tablename, V[0], V[1], tokens[7], columnindex1 - 1);
							if (linear.size() == 0)
							{
								cout << "not found..." << endl;
								break;
							}
							for (unsigned i = 0; i < linear.size(); i++)
							{
								readdata = GetRecord(tablename, linear[i], V[1]);

								for (unsigned i = 0; i < V1.size(); i++)
								{
									if (tokens[1] == V1[i])
									{
										cout << tokens[1] << ": " << readdata[i] << endl;
									}
								}
							}

						}

					}
			
			
				
				}

				//break;


			}
		
		
			cout << endl;
			cout << "Enter query> ";
			getline(cin, query);

		}
	
	
	}
