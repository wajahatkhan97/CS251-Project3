/*test.cpp*/

//
// Lab week 09 / project #04
// 
// Testing for util.cpp?
//

#include <iostream>
#include <vector>

#include "avl.h"
#include "util.h"

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

using namespace std;

TEST_CASE("(1) checking the size of the file from student") 
{
    avltree<string,streamoff>avlt;
    vector<int> keys,height,values;
    
    keys = avlt.inorder_keys();
    height = avlt.inorder_heights();
    
    REQUIRE(avlt.size()==6);
        REQUIRE(avlt.height()==2);
        

    
}
