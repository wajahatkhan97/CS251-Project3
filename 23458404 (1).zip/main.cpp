/*main.cpp*/

//
// myDB project using AVL trees
//
// Wajahat Khan
// wkhan25
// 
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project #04
//

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cassert>

#include "avl.h"
#include "util.h"

using namespace std;


//
// tokenize
//
// Given a string, breaks the string into individual tokens (words) based
// on spaces between the tokens.  Returns the tokens back in a vector.
//
// Example: "select * from students" would be tokenized into a vector
// containing 4 strings:  "select", "*", "from", "students".
//


int main()
{

	string tablename; // = "students";


	vector<int> V;
	vector<string> V1;
	cout << "Welcome to myDB, please enter tablename> ";
	getline(cin, tablename);

	readdata(tablename, V, V1); //checking index here 

	cout << "Reading meta-data..." << endl;

	cout << "Building index tree(s)..." << endl;
	avlbuild(tablename, V, V1);


	

	
	//
	return 0;
  
}
